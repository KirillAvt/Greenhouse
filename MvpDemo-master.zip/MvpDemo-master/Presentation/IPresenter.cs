﻿namespace Presentation
{
    public interface IPresenter
    {
        void Run();
    }
}